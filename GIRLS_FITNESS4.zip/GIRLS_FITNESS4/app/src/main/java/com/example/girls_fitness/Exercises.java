package com.example.girls_fitness;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.girls_fitness.beginnergym.Back;
import com.example.girls_fitness.beginnergym.Biseps;
import com.example.girls_fitness.beginnergym.Calf;
import com.example.girls_fitness.beginnergym.Cardio;
import com.example.girls_fitness.beginnergym.Chest;
import com.example.girls_fitness.beginnergym.Forearm;
import com.example.girls_fitness.beginnergym.Glutes;
import com.example.girls_fitness.beginnergym.Legs;
import com.example.girls_fitness.beginnergym.Shoulder;
import com.example.girls_fitness.beginnergym.Sidefat;
import com.example.girls_fitness.beginnergym.Triceps;

public class Exercises extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void onclick(View view)
    {
        Intent i = new Intent(this, Abs.class);
        startActivity(i);
    }
    public void onclick1(View view)
    {
        Intent i = new Intent(this, Shoulder.class);
        startActivity(i);
    }
    public void onclick2(View view)
    {
        Intent i = new Intent(this, Biseps.class);
        startActivity(i);
    }
    public void onclick3(View view)
    {
        Intent i = new Intent(this, Chest.class);
        startActivity(i);
    }
    public void onclick4(View view)
    {
        Intent i = new Intent(this, Triceps.class);
        startActivity(i);
    }
    public void onclick5(View view)
    {
        Intent i = new Intent(this, Back.class);
        startActivity(i);
    }
    public void onclick6(View view)
    {
        Intent i = new Intent(this, Cardio.class);
        startActivity(i);
    }
    public void onclick7(View view)
    {
        Intent i = new Intent(this, Forearm.class);
        startActivity(i);
    }
    public void onclick8(View view)
    {
        Intent i = new Intent(this, Legs.class);
        startActivity(i);
    }
    public void onclick9(View view)
    {
        Intent i = new Intent(this, Calf.class);
        startActivity(i);
    }
    public void onclick10(View view)
    {
        Intent i = new Intent(this, Glutes.class);
        startActivity(i);
    }
    public void onclick11(View view)
    {
        Intent i = new Intent(this, Sidefat.class);
        startActivity(i);
    }
}
