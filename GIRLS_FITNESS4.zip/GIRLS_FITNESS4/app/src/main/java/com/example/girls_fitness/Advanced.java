package com.example.girls_fitness;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.girls_fitness.advancedgym.eegymabs;
import com.example.girls_fitness.advancedgym.eegymback;
import com.example.girls_fitness.advancedgym.eegymbiseps;
import com.example.girls_fitness.advancedgym.eegymcalf;
import com.example.girls_fitness.advancedgym.eegymcardio;
import com.example.girls_fitness.advancedgym.eegymchest;
import com.example.girls_fitness.advancedgym.eegymforearm;
import com.example.girls_fitness.advancedgym.eegymglutes;
import com.example.girls_fitness.advancedgym.eegymlegs;
import com.example.girls_fitness.advancedgym.eegymshoulder;
import com.example.girls_fitness.advancedgym.eegymsidefat;
import com.example.girls_fitness.advancedgym.eegymtriceps;

public class Advanced extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
    public void onclick(View view)
    {
        Intent i = new Intent(this, eegymabs.class);
        startActivity(i);
    }
    public void onclick1(View view)
    {
        Intent i = new Intent(this, eegymshoulder.class);
        startActivity(i);
    }
    public void onclick2(View view)
    {
        Intent i = new Intent(this, eegymbiseps.class);
        startActivity(i);
    }
    public void onclick3(View view)
    {
        Intent i = new Intent(this, eegymchest.class);
        startActivity(i);
    }
    public void onclick4(View view)
    {
        Intent i = new Intent(this, eegymtriceps.class);
        startActivity(i);
    }
    public void onclick5(View view)
    {
        Intent i = new Intent(this, eegymback.class);
        startActivity(i);
    }
    public void onclick6(View view)
    {
        Intent i = new Intent(this, eegymcardio.class);
        startActivity(i);
    }
    public void onclick7(View view)
    {
        Intent i = new Intent(this, eegymforearm.class);
        startActivity(i);
    }
    public void onclick8(View view)
    {
        Intent i = new Intent(this, eegymlegs.class);
        startActivity(i);
    }
    public void onclick9(View view)
    {
        Intent i = new Intent(this, eegymcalf.class);
        startActivity(i);
    }
    public void onclick10(View view)
    {
        Intent i = new Intent(this, eegymglutes.class);
        startActivity(i);
    }
    public void onclick11(View view)
    {
        Intent i = new Intent(this, eegymsidefat.class);
        startActivity(i);
    }
}
