package com.example.girls_fitness;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.girls_fitness.intermediategym.ddgymabs;
import com.example.girls_fitness.intermediategym.ddgymback;
import com.example.girls_fitness.intermediategym.ddgymbiseps;
import com.example.girls_fitness.intermediategym.ddgymcalf;
import com.example.girls_fitness.intermediategym.ddgymcardio;
import com.example.girls_fitness.intermediategym.ddgymchest;
import com.example.girls_fitness.intermediategym.ddgymforearms;
import com.example.girls_fitness.intermediategym.ddgymglutes;
import com.example.girls_fitness.intermediategym.ddgymlegs;
import com.example.girls_fitness.intermediategym.ddgymshoulder;
import com.example.girls_fitness.intermediategym.ddgymsidefat;
import com.example.girls_fitness.intermediategym.ddgymtriceps;

public class Intermediate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
    public void onclick(View view)
    {
        Intent i = new Intent(this, ddgymabs.class);
        startActivity(i);
    }
    public void onclick1(View view)
    {
        Intent i = new Intent(this, ddgymshoulder.class);
        startActivity(i);
    }
    public void onclick2(View view)
    {
        Intent i = new Intent(this, ddgymbiseps.class);
        startActivity(i);
    }
    public void onclick3(View view)
    {
        Intent i = new Intent(this, ddgymchest.class);
        startActivity(i);
    }
    public void onclick4(View view)
    {
        Intent i = new Intent(this, ddgymtriceps.class);
        startActivity(i);
    }
    public void onclick5(View view)
    {
        Intent i = new Intent(this, ddgymback.class);
        startActivity(i);
    }
    public void onclick6(View view)
    {
        Intent i = new Intent(this, ddgymcardio.class);
        startActivity(i);
    }
    public void onclick7(View view)
    {
        Intent i = new Intent(this, ddgymforearms.class);
        startActivity(i);
    }
    public void onclick8(View view)
    {
        Intent i = new Intent(this, ddgymlegs.class);
        startActivity(i);
    }
    public void onclick9(View view)
    {
        Intent i = new Intent(this, ddgymcalf.class);
        startActivity(i);
    }
    public void onclick10(View view)
    {
        Intent i = new Intent(this, ddgymglutes.class);
        startActivity(i);
    }
    public void onclick11(View view)
    {
        Intent i = new Intent(this, ddgymsidefat.class);
        startActivity(i);
    }
}