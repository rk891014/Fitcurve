package com.example.girls_fitness;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class RecyclerAdapter extends FirebaseRecyclerAdapter<Model,RecyclerAdapter.holder>{
    private static final String TAG = "RecyclerAdapter";
    private Context mContext;
    private View view;

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public RecyclerAdapter(@NonNull FirebaseRecyclerOptions<Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull holder holder, int i, @NonNull Model model) {
        holder.rTitleTv.setText(model.getTitle());
        holder.rDescriptionTv.setText(model.getDescription());
        Log.d(TAG, "onBindViewHolder:created ");
        Log.d(TAG, model.getTitle());
        Log.d(TAG,model.getDescription());
        Log.d(TAG,model.getImage());

    }

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
      return new holder(view);
    }


    class holder extends RecyclerView.ViewHolder{
        private TextView rTitleTv;
        private TextView rDescriptionTv;
        private ImageView rImageView;

        public holder(@NonNull View itemView) {
            super(itemView);
            rTitleTv=itemView.findViewById(R.id.rTitleTv);
            rDescriptionTv=itemView.findViewById(R.id.rDescriptionTv);
            rImageView=itemView.findViewById(R.id.rImageView);

        }
    }
}
